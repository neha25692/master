#!/bin/bash
sudo yum update all -y
sudo yum install automake fuse fuse-devel gcc-c++ git libcurl-devel libxml2-devel make openssl-devel -y 
git clone https://github.com/s3fs-fuse/s3fs-fuse.git
cd s3fs-fuse
./autogen.sh
./configure --prefix=/usr --with-openssl
make
sudo make install
which s3fs
sudo mkdir -p /mmsarch

sudo s3fs -o iam_role="mms_ec2_profile" -o dbglevel=info -o curldbg -o allow_other -o use_cache=/tmp mmstest2020 /mmsarch
sudo mkdir /mmsarch/mm610lib
sudo echo s3fs#mmstest2020 /mmsarch fuse _netdev,allow_other,uid=1001,gid=0,umask=027 0 0 >> /etc/fstab


sudo yum install vsftpd -y
sudo service vsftpd start
sudo chkconfig --level 345 vsftpd on